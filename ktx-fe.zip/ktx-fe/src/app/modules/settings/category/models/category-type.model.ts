export type CategoryType = {
    id?: number;
    code?: string;
    name?: string;
}