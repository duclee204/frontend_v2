import { MenuItem } from "primeng/api";
import { RESOURCE } from "src/app/core/app-config";

export const MENU_CONFIG = [];